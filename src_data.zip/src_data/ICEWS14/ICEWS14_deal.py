import pandas as pd

# ==========================
# 配置区
# ==========================
data_path = 'total.xlsx'  # 原始数据文件路径
train_path = 'train.xlsx'
valid_path = 'valid.xlsx'
test_path = 'test.xlsx'

# ==========================
# 1. 读取数据
# ==========================
df = pd.read_excel(data_path, sheet_name='Sheet1')

# 检查列
if 'timestamp' not in df.columns:
    raise ValueError("数据文件中必须包含 'timestamp' 列")

# ==========================
# 2. 按时间戳升序排序
# ==========================
df_sorted = df.sort_values(by='timestamp').reset_index(drop=True)

# ==========================
# 3. 按比例切分
# ==========================
total = len(df_sorted)
train_end = int(total * 0.7)
valid_end = int(total * 0.8)

train_df = df_sorted.iloc[:train_end]
valid_df = df_sorted.iloc[train_end:valid_end]
test_df = df_sorted.iloc[valid_end:]

# ==========================
# 4. 保存为 Excel 文件（保留列信息）
# ==========================
train_df.to_excel(train_path, index=False)
valid_df.to_excel(valid_path, index=False)
test_df.to_excel(test_path, index=False)

# ==========================
# 5. 输出样本数
# ==========================
print(f"训练集样本数: {len(train_df)}")
print(f"验证集样本数: {len(valid_df)}")
print(f"测试集样本数: {len(test_df)}")

